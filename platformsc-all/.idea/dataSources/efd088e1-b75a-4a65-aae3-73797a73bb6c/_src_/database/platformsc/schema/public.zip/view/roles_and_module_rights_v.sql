CREATE VIEW roles_and_module_rights_v AS SELECT r.id_role AS id,
    r.id_role,
    NULL::bigint AS id_module_right,
    0 AS type
   FROM t_role r
UNION
 SELECT (m.id_module_right + 10000) AS id,
    NULL::bigint AS id_role,
    m.id_module_right,
    1 AS type
   FROM t_module_right m;
