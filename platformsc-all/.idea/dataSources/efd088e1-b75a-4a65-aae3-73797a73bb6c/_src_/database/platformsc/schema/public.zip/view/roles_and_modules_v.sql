CREATE VIEW roles_and_modules_v AS SELECT r.id_role AS id,
    r.id_role,
    NULL::bigint AS id_module,
    r.description,
    0 AS type
   FROM t_role r
  WHERE (NOT (r.id_role IN ( SELECT rr.fk_role_compose
           FROM t_role_role rr)))
UNION
 SELECT (m.id_module + 10000) AS id,
    NULL::bigint AS id_role,
    m.id_module,
    m.description,
    2 AS type
   FROM t_module m;
